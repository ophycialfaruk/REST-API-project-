# Express API Project

## Setup Instructions

1. Install Node.js and npm if not already installed.
2. Navigate to the project directory.
3. Run `npm install` to install dependencies.
4. Run `npm start` to start the server.
5. The server will run at `http://localhost:3000`.

## API Documentation

### Root
- `GET /` - Returns "Hello, World!"

### Items
- `GET /items` - Retrieve all items
- `GET /items/:id` - Retrieve item by ID
- `POST /items` - Create item (JSON: `{ "name": "Item1", "description": "Description" }`)
- `PUT /items/:id` - Update item (JSON: `{ "name": "Updated", "description": "Updated Desc" }`)
- `DELETE /items/:id` - Delete item

### Error Handling
- 400 for invalid inputs
- 404 for not found
- 500 for server errors

## Example Requests (Postman)
- Create: POST /items
```json
{
  "name": "Sample Item",
  "description": "Sample Description"
}
```

- Get All: GET /items
- Get One: GET /items/1
- Update: PUT /items/1
- Delete: DELETE /items/1
