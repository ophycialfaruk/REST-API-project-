const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

let items = [];
let idCounter = 1;

// Root route
app.get('/', (req, res) => {
    res.send('Hello, World!');
});

// Get all items
app.get('/items', (req, res) => {
    res.json(items);
});

// Get item by ID
app.get('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const item = items.find(i => i.id === id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
});

// Create new item
app.post('/items', (req, res) => {
    const { name, description } = req.body;
    if (!name || !description) {
        return res.status(400).json({ error: 'Name and description are required' });
    }
    const newItem = { id: idCounter++, name, description };
    items.push(newItem);
    res.status(201).json(newItem);
});

// Update item by ID
app.put('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const item = items.find(i => i.id === id);
    if (!item) return res.status(404).json({ error: 'Item not found' });

    const { name, description } = req.body;
    if (!name || !description) {
        return res.status(400).json({ error: 'Name and description are required' });
    }

    item.name = name;
    item.description = description;
    res.json(item);
});

// Delete item by ID
app.delete('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = items.findIndex(i => i.id === id);
    if (index === -1) return res.status(404).json({ error: 'Item not found' });
    items.splice(index, 1);
    res.status(204).send();
});

// Handle invalid routes
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
